function scrollToAnchor(aid){
    var aTag = $("a[name='"+ aid +"']");
    $('html,body').animate({scrollTop: aTag.offset().top},'slow');
}
$("#learn").click(function() {
   scrollToAnchor('rotors');
});
$("#footernav").click(function() {
   scrollToAnchor('footer');
});

$("#contact2").click(function() {
   scrollToAnchor('footer');
});

